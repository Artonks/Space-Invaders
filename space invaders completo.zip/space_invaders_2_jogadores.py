"""
Space Invaders - JOGADOR 1 contra JOGADOR 2  (versão com sprites)
=================================================================
- Jogador 1 (embaixo) defende a Terra e destrói os inimigos.
- Jogador 2 (em cima, ATRÁS dos inimigos) comanda a invasão e atira contra o Jogador 1.
  Ele usa a MESMA nave do Jogador 1, só que virada para baixo e pintada com a cor dos inimigos.
- Sempre que os inimigos descem uma linha, o Jogador 2 desce junto, na mesma medida.
- Os tiros do Jogador 2 atravessam os inimigos: ele NÃO consegue destruir os bots.

COMO SE VENCE
  Jogador 1 vence: destrói o Jogador 2 (acertando-o 3 vezes).
  Jogador 2 vence: zera as vidas do Jogador 1 OU deixa os inimigos chegarem até a nave dele.
  Os inimigos do computador (bots) também atiram no Jogador 1 e, quando todos morrem,
  vem uma nova onda (mais rápida, e de OUTRA COR) depois de uma pequena pausa.
  A cor do Jogador 2 muda junto com a cor dos inimigos de cada onda.

CONTROLES
  Jogador 1:  A / D = mover  |  W ou ESPAÇO = atirar
  Jogador 2:  SETA ESQUERDA / SETA DIREITA = mover  |  SETA PARA BAIXO = atirar
  R = reiniciar (no fim)  |  ESC = sair

ARQUIVOS: deixe  sprites.png  e  fundo.png  na MESMA pasta deste arquivo .py
Para rodar:  py -3.12 space_invaders_2_jogadores.py

OTIMIZAÇÕES USADAS (para explicar na apresentação)
  * A folha de sprites é carregada UMA vez e cada quadro de animação é recortado e
    ampliado UMA vez, no início (nada é recortado ou ampliado durante o jogo).
  * A nave do Jogador 2 é virada e pintada UMA vez por cor (4 cores), também no início.
  * O fundo são duas imagens pré-convertidas que só rolam (2 blits cada), sem criar objetos.
  * Textos são desenhados UMA vez e guardados em cache (lru_cache).
  * A "caixa" que envolve todos os inimigos vem de uma única chamada em C (unionall).
  * Os inimigos andam com move_ip (move o retângulo no lugar, sem criar objetos novos).
  * Cada lista de tiros é filtrada UMA vez por quadro (sem remove() dentro de laços).
  * Toda a configuração fica em constantes no topo.
"""
import os
import random
from functools import lru_cache

import pygame

# ---------------------------------------------------------------------------
# CONFIGURAÇÃO (mude os números aqui para equilibrar o jogo)
# ---------------------------------------------------------------------------
LARGURA, ALTURA = 800, 600
FPS = 60
VIDAS_P1, VIDAS_P2 = 4, 3          # o P1 tem mais vidas porque enfrenta P2 E os bots
VEL_NAVE = 6                       # pixels por quadro
RECARGA_P1, RECARGA_P2 = 15, 18    # quadros entre tiros (o P2 atira um pouco mais devagar)
VEL_TIRO_P1, VEL_TIRO_P2, VEL_TIRO_BOT = 10, 7, 5
CHANCE_TIRO_BOT = 0.012            # chance, por quadro, de algum bot atirar
INVULNERAVEL = 60                  # quadros sem levar dano depois de ser atingido (1 segundo)
ESPACO_COLUNAS = 46                # distância entre colunas de bots (bot = 40 de largura)
DESCIDA = 20                       # quanto os bots (e o P2) descem ao bater na borda
PAUSA_ENTRE_ONDAS = 90             # quadros sem inimigos antes da próxima onda (o P2 fica exposto!)
VEL_VOLTA_P2 = 6                   # velocidade com que o P2 sobe de volta ao topo entre as ondas
ESCALA = 2                         # ampliação dos sprites das naves e dos tiros
PASSO_ANIM_BOT = 10                # quadros de jogo por quadro de animação dos bots
PASSO_ANIM_NAVE = 6                # idem para as naves dos jogadores
P2_Y_INICIAL = 8                   # altura do P2 no topo da tela

BRANCO = (255, 255, 255)
COR_P1 = (0, 255, 0)               # só usada nos textos do HUD
COR_P2 = (255, 0, 255)

# ---------------------------------------------------------------------------
# TABELA DOS SPRITES DOS INIMIGOS DENTRO DE sprites.png
# Cada conjunto (uma cor) tem 6 linhas: (y, altura, [(x, largura) de cada quadro])
#   ordem das linhas: lula andando, lula morrendo, caranguejo andando, caranguejo morrendo,
#                     polvo andando, polvo morrendo     (andando = 4 quadros, morrendo = 3)
# ---------------------------------------------------------------------------
CONJUNTOS = [
    ("vermelho", (235, 35, 35), [
        (449, 17, [(177, 14), (195, 10), (210, 12), (226, 12)]),
        (468, 17, [(184, 14), (200, 16), (218, 14)]),
        (488, 15, [(173, 16), (191, 16), (209, 16), (227, 16)]),
        (506, 17, [(181, 16), (199, 16), (217, 16)]),
        (526, 16, [(171, 16), (189, 16), (207, 16), (225, 16)]),
        (544, 17, [(180, 16), (198, 16), (216, 16)]),
    ]),
    ("laranja", (255, 140, 20), [
        (315, 15, [(175, 16), (193, 16), (211, 14), (227, 16)]),
        (330, 17, [(182, 16), (200, 16), (218, 16)]),
        (349, 14, [(177, 14), (193, 14), (209, 16), (227, 16)]),
        (364, 17, [(186, 14), (202, 14), (218, 14)]),
        (382, 16, [(178, 12), (193, 14), (209, 16), (227, 16)]),
        (398, 17, [(183, 14), (200, 14), (217, 14)]),
    ]),
    ("ciano", (40, 200, 240), [
        (186, 13, [(177, 12), (192, 14), (208, 14), (225, 12)]),
        (200, 17, [(184, 10), (200, 10), (216, 10)]),
        (219, 14, [(172, 16), (190, 16), (208, 16), (226, 16)]),
        (233, 16, [(183, 14), (199, 14), (215, 14)]),
        (251, 15, [(169, 16), (187, 16), (207, 16), (227, 16)]),
        (266, 15, [(183, 16), (199, 16), (215, 16)]),
    ]),
    ("cinza", (200, 200, 200), [
        (62, 11, [(178, 10), (194, 10), (210, 10), (226, 10)]),
        (74, 17, [(185, 9), (202, 8), (218, 9)]),
        (92, 11, [(176, 13), (191, 15), (208, 15), (225, 13)]),
        (104, 17, [(186, 12), (199, 18), (218, 12)]),
        (122, 11, [(177, 14), (193, 14), (209, 14), (225, 16)]),
        (135, 17, [(186, 11), (201, 12), (217, 12)]),
    ]),
]

FORMACAO = (0, 1, 1, 2)            # tipo de bot de cada linha da grade (lula, caranguejo, caranguejo, polvo)

# ---------------------------------------------------------------------------
# PREPARAÇÃO DO PYGAME
# ---------------------------------------------------------------------------
pygame.init()
tela = pygame.display.set_mode((LARGURA, ALTURA))
pygame.display.set_caption("Space Invaders - Jogador 1 vs Jogador 2")
relogio = pygame.time.Clock()            # segura o jogo em 60 quadros por segundo
fonte = pygame.font.Font(None, 30)
fonte_grande = pygame.font.Font(None, 48)
AREA = tela.get_rect()                   # retângulo da janela (limite das naves)

PASTA = os.path.dirname(os.path.abspath(__file__))
for nome in ("sprites.png", "fundo.png"):
    if not os.path.exists(os.path.join(PASTA, nome)):
        raise SystemExit(f"Falta o arquivo '{nome}'. Coloque-o na mesma pasta do jogo: {PASTA}")

MENSAGENS = {                            # texto de fim de jogo para cada resultado
    1: ("JOGADOR 1 VENCEU! A invasão foi destruída.", COR_P1),
    2: ("JOGADOR 2 VENCEU! A Terra caiu.", COR_P2),
    3: ("EMPATE! Os dois caíram juntos.", BRANCO),
}


@lru_cache(maxsize=128)
def texto(mensagem, cor, grande=False):
    """Cria a imagem de um texto. O lru_cache guarda os resultados: o mesmo texto
    (por exemplo 'P1 Vidas: 5') só é desenhado uma vez, mesmo usado em milhares de quadros."""
    return (fonte_grande if grande else fonte).render(mensagem, True, cor)


# ---------------------------------------------------------------------------
# CARREGAMENTO DOS SPRITES (tudo feito UMA vez, antes do jogo começar)
# ---------------------------------------------------------------------------
folha = pygame.image.load(os.path.join(PASTA, "sprites.png")).convert_alpha()


def recorte(x, y, w, h, escala=ESCALA, inverter=False):
    """Recorta um pedaço da folha e amplia sem borrar (pixel art). inverter=True vira de cabeça para baixo."""
    img = pygame.transform.scale(folha.subsurface((x, y, w, h)), (w * escala, h * escala))
    return pygame.transform.flip(img, False, True) if inverter else img


def tingir(img, cor):
    """Pinta a nave com a cor dada, mantendo o contorno preto e os brilhos (feito UMA vez)."""
    nova = img.copy()
    for x in range(nova.get_width()):
        for y in range(nova.get_height()):
            r, g, b, a = nova.get_at((x, y))
            if a:
                brilho = (r * 30 + g * 59 + b * 11) / 100 / 150     # 0 = preto, 1 = cinza médio, >1 = brilho
                if brilho <= 1:
                    novo = [int(c * brilho) for c in cor]
                else:
                    t = min(1, (brilho - 1) / 0.7)
                    novo = [int(c + (255 - c) * t) for c in cor]
                nova.set_at((x, y), (*novo, a))
    return nova


def escala_do_bot(largura, altura):
    """Maior ampliação inteira em que o bot ainda cabe na caixa de 44 x 36."""
    return max(1, min(44 // largura, 36 // altura))


# Inimigos: ANIM_BOT[conjunto][tipo] = 4 quadros andando | MORTE_BOT[conjunto][tipo] = 3 quadros explodindo
ANIM_BOT, MORTE_BOT = [], []
for _nome, _cor, _linhas in CONJUNTOS:
    anim, morte = [], []
    for tipo in range(3):
        y, h, quadros = _linhas[tipo * 2]
        e = escala_do_bot(max(w for _, w in quadros), h)
        anim.append([recorte(x, y, w, h, e) for x, w in quadros])
        y, h, quadros = _linhas[tipo * 2 + 1]
        morte.append([recorte(x, y, w, h, e) for x, w in quadros])
    ANIM_BOT.append(anim)
    MORTE_BOT.append(morte)

# Naves dos jogadores: na folha há 8 quadros de 16x16, de 18 em 18 pixels:
#   0-3 = nave parada (o motor "pisca")  |  4-6 = sendo destruída  |  7 = explosão de fogo
NAVE_P1 = [recorte(120 + 18 * i, 654, 16, 16) for i in range(8)]
# O Jogador 2 usa os MESMOS quadros, mas de cabeça para baixo e pintados com a cor de cada conjunto
NAVE_P2 = [[tingir(recorte(120 + 18 * i, 654, 16, 16, inverter=True), cor) for i in range(8)]
           for _nome, cor, _linhas in CONJUNTOS]

# Explosão grande (sequência final das naves destruídas): bola grande, depois três círculos menores
EXPLOSAO_GRANDE = [recorte(268, 657, 32, 32), recorte(166, 566, 32, 32),
                   recorte(203, 570, 25, 25), recorte(231, 575, 16, 15)]

# Tiros e efeitos
SPR_TIRO_P1 = recorte(161, 634, 4, 12)                              # barra verde
SPR_TIRO_P2 = [recorte(213, 606, 7, 10), recorte(225, 606, 7, 10)]  # orbe vermelho (2 quadros)
SPR_TIRO_BOT = [recorte(184, 603, 4, 15), recorte(193, 603, 4, 15)] # raio branco em zigue-zague (2 quadros)
FX_CLARAO = [recorte(120, 633, 16, 15, e) for e in (2, 3, 2)]       # bola de fogo ao ser atingido
FX_FAISCA = [recorte(191, 632, 16, 16, e) for e in (1, 2, 3)]       # 4 faíscas que se afastam
FX_BOCA = [recorte(171, 632, 16, 16, e) for e in (1, 2)]            # anel verde: lampejo do cano

# Fundo: a imagem é cortada 4 px nas bordas (tem uma moldura cinza) e esticada para a tela.
# Duas camadas (a segunda virada ao contrário) rolam em velocidades diferentes = profundidade.
_fundo_cru = pygame.image.load(os.path.join(PASTA, "fundo.png")).convert()
_fundo_cru = _fundo_cru.subsurface((4, 4, _fundo_cru.get_width() - 8, _fundo_cru.get_height() - 8))
FUNDO_A = pygame.transform.smoothscale(_fundo_cru, (LARGURA, ALTURA)).convert()
FUNDO_B = pygame.transform.flip(FUNDO_A, True, True)
FUNDO_A.fill((170, 170, 170), special_flags=pygame.BLEND_RGB_MULT)   # escurece as camadas para os sprites
FUNDO_B.fill((90, 90, 90), special_flags=pygame.BLEND_RGB_MULT)      # ganharem destaque
VEL_FUNDO_A, VEL_FUNDO_B = 0.4, 1.1     # pixels por quadro


def criar_inimigos():
    """Grade de bots: 4 linhas x 8 colunas, bem juntinhas (só 6 pixels de brecha entre
    elas), então os bots funcionam como ESCUDO para o Jogador 2: o Jogador 1 precisa
    destruir uma coluna inteira para abrir um caminho até ele.
    Começam em y=100 para sobrar espaço em cima para o P2 e para a barra de informações."""
    x_inicial = (LARGURA - (7 * ESPACO_COLUNAS + 40)) // 2      # centraliza a grade na tela
    grade = []
    for linha in range(4):
        for coluna in range(8):
            bot = pygame.Rect(x_inicial + coluna * ESPACO_COLUNAS, 100 + linha * 50, 40, 30)
            grade.append(Inimigo(bot, FORMACAO[linha]))
    return grade


class Inimigo(pygame.Rect):
    """Um Rect comum (então unionall, collidelist e move_ip continuam funcionando) que
    também guarda o TIPO do bot (0 lula, 1 caranguejo, 2 polvo) para escolher o sprite."""
    def __init__(self, retangulo, tipo):
        super().__init__(retangulo)
        self.tipo = tipo


def acertar(tiros, alvo):
    """Separa os tiros que acertaram o alvo dos que não acertaram.
    Devolve (tiros que continuam voando, quantos acertaram)."""
    restantes = [t for t in tiros if not t.colliderect(alvo)]
    return restantes, len(tiros) - len(restantes)


def efeito(quadros, centro, passo=5):
    """Cria uma animação de uma vez só (explosão, faísca...). Ela se apaga sozinha no fim."""
    efeitos.append([quadros, centro, 0, passo])


def morte_da_nave(quadros_nave, centro):
    """Sequência de destruição de uma nave: quadros 4 a 7 da nave + explosão grande."""
    efeito(quadros_nave[4:8] + EXPLOSAO_GRANDE, centro, 7)


def iniciar():
    """Coloca o jogo no estado inicial (também usada para reiniciar)."""
    global p1, p2, tiros_p1, tiros_p2, tiros_bot, inimigos, direcao, velocidade
    global recarga1, recarga2, vidas1, vidas2, inv1, inv2, onda, espera, vencedor
    global efeitos, morto1, morto2, conjunto
    p1 = pygame.Rect(LARGURA // 2 - 16, ALTURA - 40, 32, 32)         # nave do Jogador 1 (embaixo)
    p2 = pygame.Rect(LARGURA // 2 - 16, P2_Y_INICIAL, 32, 32)        # nave do Jogador 2 (em cima)
    tiros_p1, tiros_p2, tiros_bot = [], [], []                       # três listas de tiros
    efeitos = []                                                     # animações em andamento
    inimigos = criar_inimigos()
    direcao = 1            # 1 = bots vão para a direita, -1 = para a esquerda
    velocidade = 2         # pixels por quadro dos bots
    recarga1 = recarga2 = 0
    vidas1, vidas2 = VIDAS_P1, VIDAS_P2
    inv1 = inv2 = 0        # quadros de invulnerabilidade restantes de cada jogador
    onda = 1
    conjunto = 0           # cor dos inimigos (e do P2) da onda atual
    espera = 0             # contagem da pausa entre ondas
    morto1 = morto2 = False   # True = a nave já explodiu e não é mais desenhada
    vencedor = 0           # 0 = jogo em andamento | 1, 2 ou 3 = resultado (ver MENSAGENS)


iniciar()
quadro = 0                 # contador de quadros: move as animações e o fundo

# ---------------------------------------------------------------------------
# LAÇO PRINCIPAL: repete 60 vezes por segundo (eventos -> lógica -> desenho)
# ---------------------------------------------------------------------------
while True:
    relogio.tick(FPS)
    quadro += 1

    # 1) EVENTOS: fechar a janela, ESC para sair e R para reiniciar
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            raise SystemExit
        if evento.type == pygame.KEYDOWN:
            if evento.key == pygame.K_ESCAPE:
                raise SystemExit
            if evento.key == pygame.K_r and vencedor:
                iniciar()

    if not vencedor:
        teclas = pygame.key.get_pressed()

        # 2) JOGADOR 1: (D - A) vale +1, -1 ou 0 (as teclas são True/False = 1/0)
        p1.x += (teclas[pygame.K_d] - teclas[pygame.K_a]) * VEL_NAVE
        p1.clamp_ip(AREA)                              # impede de sair da tela
        recarga1 -= 1
        if (teclas[pygame.K_w] or teclas[pygame.K_SPACE]) and recarga1 <= 0:
            tiros_p1.append(pygame.Rect(p1.centerx - 4, p1.top - 24, 8, 24))
            efeito(FX_BOCA, (p1.centerx, p1.top), 3)           # lampejo no cano
            recarga1 = RECARGA_P1

        # 3) JOGADOR 2: o mesmo, com as setas; atira PARA BAIXO com a seta para baixo
        p2.x += (teclas[pygame.K_RIGHT] - teclas[pygame.K_LEFT]) * VEL_NAVE
        p2.clamp_ip(AREA)
        recarga2 -= 1
        if teclas[pygame.K_DOWN] and recarga2 <= 0:
            tiros_p2.append(pygame.Rect(p2.centerx - 7, p2.bottom, 14, 20))
            efeito(FX_BOCA, (p2.centerx, p2.bottom), 3)
            recarga2 = RECARGA_P2

        # 4) CRONÔMETROS de invulnerabilidade (nunca abaixo de zero)
        inv1 = max(0, inv1 - 1)
        inv2 = max(0, inv2 - 1)

        # 5) MOVER OS TIROS e apagar os que saíram da tela (uma filtragem por lista)
        for tiro in tiros_p1:
            tiro.y -= VEL_TIRO_P1                      # o tiro do P1 sobe
        for tiro in tiros_p2:
            tiro.y += VEL_TIRO_P2                      # os tiros do P2 e dos bots descem
        for tiro in tiros_bot:
            tiro.y += VEL_TIRO_BOT
        tiros_p1 = [t for t in tiros_p1 if t.bottom > 0]
        tiros_p2 = [t for t in tiros_p2 if t.top < ALTURA]
        tiros_bot = [t for t in tiros_bot if t.top < ALTURA]

        # 6) TIROS DO P1 x BOTS: o tiro some e o bot morre (collidelist devolve o índice ou -1).
        #    Os tiros do P2 NÃO entram aqui: eles atravessam os bots sem machucá-los.
        sobraram = []
        for tiro in tiros_p1:
            indice = tiro.collidelist(inimigos)
            if indice == -1:
                sobraram.append(tiro)
            else:
                morto = inimigos.pop(indice)
                efeito(MORTE_BOT[conjunto][morto.tipo], morto.center, 6)   # animação de explosão
        tiros_p1 = sobraram

        # 7) TIROS DO P1 x JOGADOR 2: o tiro some; se o P2 não está invulnerável, perde 1 vida
        tiros_p1, acertos = acertar(tiros_p1, p2)
        if acertos and not inv2:
            vidas2 -= 1
            inv2 = INVULNERAVEL
            efeito(FX_CLARAO, p2.center, 5)

        # 8) TIROS DO P2 e DOS BOTS x JOGADOR 1: somem ao acertar; no máximo 1 vida por vez
        tiros_p2, a = acertar(tiros_p2, p1)
        tiros_bot, b = acertar(tiros_bot, p1)
        if (a or b) and not inv1:
            vidas1 -= 1
            inv1 = INVULNERAVEL
            efeito(FX_CLARAO, p1.center, 5)
            efeito(FX_FAISCA, p1.center, 5)

        # 9) BOTS: se ainda existem, movem e atiram; se acabaram, contam a pausa e criam a próxima onda
        if inimigos:
            caixa = inimigos[0].unionall(inimigos[1:])       # retângulo que envolve TODOS os bots
            deslocamento = direcao * velocidade
            if caixa.left + deslocamento < 0 or caixa.right + deslocamento > LARGURA:
                direcao = -direcao                           # bateu na borda: inverte e desce
                for inimigo in inimigos:
                    inimigo.move_ip(0, DESCIDA)
                p2.y += DESCIDA                              # o Jogador 2 desce JUNTO, na mesma medida
            else:
                for inimigo in inimigos:
                    inimigo.move_ip(deslocamento, 0)
            if random.random() < CHANCE_TIRO_BOT:            # um bot aleatório atira
                atirador = random.choice(inimigos)
                tiros_bot.append(pygame.Rect(atirador.centerx - 4, atirador.bottom, 8, 30))
            invadiu = caixa.bottom >= p1.top                 # os bots chegaram na nave do P1?
        else:
            invadiu = False
            p2.y = max(P2_Y_INICIAL, p2.y - VEL_VOLTA_P2)    # sem escudo: o P2 volta para o topo
            if not espera:
                espera = PAUSA_ENTRE_ONDAS                   # acabou de limpar: começa a pausa
            espera -= 1
            if not espera:                                   # fim da pausa: nova onda, mais rápida
                onda += 1
                velocidade = min(1 + onda, 8)
                conjunto = (onda - 1) % len(CONJUNTOS)       # nova cor de inimigos (e de P2)
                inimigos = criar_inimigos()
                tiros_bot = []
                p2.y = P2_Y_INICIAL

        # 10) FIM DE JOGO: confere quem venceu e inicia a explosão das naves derrotadas
        if vidas1 <= 0 and vidas2 <= 0:
            vencedor = 3
        elif vidas1 <= 0 or invadiu:
            vencedor = 2
        elif vidas2 <= 0:
            vencedor = 1
        if vencedor in (2, 3) and not morto1:
            morto1 = True
            morte_da_nave(NAVE_P1, p1.center)
        if vencedor in (1, 3) and not morto2:
            morto2 = True
            morte_da_nave(NAVE_P2[conjunto], p2.center)

    # 11) ANIMAÇÕES: avançam sempre (até na tela de fim de jogo) e as terminadas são apagadas
    for e in efeitos:
        e[2] += 1
    efeitos = [e for e in efeitos if e[2] // e[3] < len(e[0])]

    # 12) DESENHO: fundo rolando, depois cada sprite
    y = int(quadro * VEL_FUNDO_A) % ALTURA          # camada 1 (opaca) rola devagar...
    tela.blit(FUNDO_A, (0, y - ALTURA))
    tela.blit(FUNDO_A, (0, y))
    y = int(quadro * VEL_FUNDO_B) % ALTURA           # ...camada 2 (somada) rola mais rápido
    tela.blit(FUNDO_B, (0, y - ALTURA), special_flags=pygame.BLEND_RGB_ADD)
    tela.blit(FUNDO_B, (0, y), special_flags=pygame.BLEND_RGB_ADD)

    passo_bot = quadro // PASSO_ANIM_BOT % 4          # qual quadro da animação os bots mostram agora
    for inimigo in inimigos:
        imagem = ANIM_BOT[conjunto][inimigo.tipo][passo_bot]
        tela.blit(imagem, imagem.get_rect(center=inimigo.center))

    passo_tiro = quadro // 6 % 2                      # os tiros de P2 e dos bots têm 2 quadros
    for tiro in tiros_p1:
        tela.blit(SPR_TIRO_P1, SPR_TIRO_P1.get_rect(center=tiro.center))
    for tiro in tiros_p2:
        tela.blit(SPR_TIRO_P2[passo_tiro], SPR_TIRO_P2[passo_tiro].get_rect(center=tiro.center))
    for tiro in tiros_bot:
        tela.blit(SPR_TIRO_BOT[passo_tiro], SPR_TIRO_BOT[passo_tiro].get_rect(center=tiro.center))

    # a nave pisca (some e volta) enquanto está invulnerável; o "motor" anima nos quadros 0 a 3
    passo_nave = quadro // PASSO_ANIM_NAVE % 4
    if not morto1 and inv1 % 10 < 5:
        tela.blit(NAVE_P1[passo_nave], p1)
    if not morto2 and inv2 % 10 < 5:
        tela.blit(NAVE_P2[conjunto][passo_nave], p2)

    for quadros, centro, tempo, passo in efeitos:     # explosões, faíscas e lampejos por cima de tudo
        imagem = quadros[tempo // passo]
        tela.blit(imagem, imagem.get_rect(center=centro))

    # informações: vidas de cada jogador e a onda atual
    tela.blit(texto(f"P1  Vidas: {vidas1}", COR_P1), (10, 45))
    tela.blit(texto(f"Onda {onda}", BRANCO), (LARGURA // 2 - 35, 45))
    imagem = texto(f"P2  Vidas: {vidas2}", COR_P2)
    tela.blit(imagem, (LARGURA - imagem.get_width() - 10, 45))

    if vencedor:
        mensagem, cor = MENSAGENS[vencedor]
        imagem = texto(mensagem, cor, True)
        tela.blit(imagem, imagem.get_rect(center=(LARGURA // 2, ALTURA // 2)))
        imagem = texto("R: jogar de novo   |   ESC: sair", BRANCO)
        tela.blit(imagem, imagem.get_rect(center=(LARGURA // 2, ALTURA // 2 + 50)))

    pygame.display.flip()   # mostra na tela tudo o que foi desenhado
